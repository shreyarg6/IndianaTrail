package Program;
/**
 * @author Shreya G
 * @date 4/15/22
 * @Purdue CNIT 255
 */
public interface PlayerActivity 
{
    public void buyWater();
    public void buyBandaid();
    public void buyGauze();
    public void moveForward();
}
